import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MenuScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    TextStyle kMenuTextStyle = GoogleFonts.poppins(
        color: Colors.white, fontSize: 23.0, fontWeight: FontWeight.w300);
    return Container(
      width: MediaQuery.of(context).size.width,
      color: Colors.black,
      child: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('HOME', style: kMenuTextStyle),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('EVENTS', style: kMenuTextStyle),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('PROJECTS', style: kMenuTextStyle),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('TEAM', style: kMenuTextStyle),
            ),
          ],
        ),
      ),
    );
  }
}
