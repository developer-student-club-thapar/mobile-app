import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MemberCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
        child: Stack(
      children: <Widget>[
        Container(
          child: Image.asset('lib/assets/dsc_logo.png'),
        ),
        Text(
          'Sundar Pichai',
          style: GoogleFonts.poppins(fontSize: 12.0, color: Colors.black),
        ),
        Text(
          'Moderator',
          style: GoogleFonts.poppins(
              fontSize: 8.0, color: Color.fromRGBO(192, 192, 192, 1.0)),
        ),
     
      ],
    ));
  }
}
